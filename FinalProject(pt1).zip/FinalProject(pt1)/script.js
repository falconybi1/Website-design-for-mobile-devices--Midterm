const salesPieChart = document.getElementById('sales-pie-chart').getContext('2d');
new Chart(salesPieChart, {
  type: 'pie',
  data: {
    labels: ['Espresso', 'Latte', 'Cappuccino', 'Americano'],
    datasets: [{
      label: 'Sales by Coffee Type',
      data: [1000, 900, 700, 500],
      backgroundColor: ['#6f4e37', '#d3a179', '#a67b5b', '#c4a484'],
      borderColor: ['#6f4e37', '#d3a179', '#a67b5b', '#c4a484'],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { position: 'top' },
    }
  }
});

const revenueLineChart = document.getElementById('revenue-line-chart').getContext('2d');
new Chart(revenueLineChart, {
  type: 'line',
  data: {
    labels: ['Brazil', 'Spain', 'Greece', 'Mexico'],
    datasets: [{
      label: 'Revenue (USD)',
      data: [30000, 25000, 20000, 15000],
      borderColor: '#d3a179',
      backgroundColor: 'rgba(211, 161, 121, 0.2)',
      fill: true,
      tension: 0.4
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});

const regionBarChart = document.getElementById('region-bar-chart').getContext('2d');
new Chart(regionBarChart, {
  type: 'bar',
  data: {
    labels: ['Brazil', 'Spain', 'Greece', 'Mexico'],
    datasets: [{
      label: 'Units Sold',
      data: [1000, 900, 700, 500],
      backgroundColor: ['#6f4e37', '#d3a179', '#a67b5b', '#c4a484'],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});
